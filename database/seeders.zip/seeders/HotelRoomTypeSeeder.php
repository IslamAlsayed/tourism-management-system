<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class HotelRoomTypeSeeder extends Seeder
{
    public function run()
    {
        DB::table('hotel_room_types')->insert([
            [
                'hotel_id' => 1,
                'name_ar' => 'غرفة قياسية',
                'name_en' => 'Standard Room',
                'max_occupancy' => 3,
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'hotel_id' => 1,
                'name_ar' => 'غرفة سوبيريور',
                'name_en' => 'Superior Room',
                'max_occupancy' => 4,
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'hotel_id' => 2,
                'name_ar' => 'غرفة مزدوجة',
                'name_en' => 'Double Room',
                'max_occupancy' => 2,
                'created_at' => now(),
                'updated_at' => now()
            ]
        ]);
    }
}