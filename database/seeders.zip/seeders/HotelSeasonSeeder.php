<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class HotelSeasonSeeder extends Seeder
{
    public function run()
    {
        DB::table('hotel_seasons')->insert([
            [
                'hotel_id' => 1,
                'season_name' => 'Low Season',
                'start_date' => '2025-01-01',
                'end_date' => '2025-02-28',
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'hotel_id' => 1,
                'season_name' => 'High Season',
                'start_date' => '2025-03-01',
                'end_date' => '2025-05-31',
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'hotel_id' => 2,
                'season_name' => 'Low Season',
                'start_date' => '2025-01-01',
                'end_date' => '2025-02-28',
                'created_at' => now(),
                'updated_at' => now()
            ]
        ]);
    }
}