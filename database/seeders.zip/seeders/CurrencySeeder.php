<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class CurrencySeeder extends Seeder
{
    public function run()
    {
        // تعطيل قيود المفاتيح الأجنبية مؤقتًا
        Schema::disableForeignKeyConstraints();
        DB::table('currencies')->truncate();
        Schema::enableForeignKeyConstraints();

        DB::table('currencies')->insert([
            [
                'code' => 'JOD',
                'name' => 'دينار أردني',
                'name_ar' => 'دينار أردني',
                'name_en' => 'Jordanian Dinar',
                'symbol' => 'JD',
                'exchange_rate' => 1.000,
                'decimal_places' => 3,
                'is_active' => true,
                'is_major_currency' => true,
                'is_base_currency' => true,
                'sort_order' => 1,
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'code' => 'USD',
                'name' => 'دولار أمريكي',
                'name_ar' => 'دولار أمريكي',
                'name_en' => 'US Dollar',
                'symbol' => '$',
                'exchange_rate' => 0.709,
                'decimal_places' => 2,
                'is_active' => true,
                'is_major_currency' => true,
                'is_base_currency' => false,
                'sort_order' => 2,
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'code' => 'EUR',
                'name' => 'يورو',
                'name_ar' => 'يورو',
                'name_en' => 'Euro',
                'symbol' => '€',
                'exchange_rate' => 0.66,
                'decimal_places' => 2,
                'is_active' => true,
                'is_major_currency' => true,
                'is_base_currency' => false,
                'sort_order' => 3,
                'created_at' => now(),
                'updated_at' => now()
            ]
        ]);
    }
}