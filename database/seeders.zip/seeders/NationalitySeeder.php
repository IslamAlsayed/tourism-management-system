<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class NationalitySeeder extends Seeder
{
    public function run(): void
    {
        DB::table('nationalities')->insert([
            [
                'id' => 1,
                'country_id' => 1, // ضع هنا رقم الدولة المناسبة من جدول countries
                'nationality_ar' => 'أردني',
                'nationality_en' => 'Jordanian',
                'is_active' => true,
                'nationality_id' => null,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'id' => 2,
                'country_id' => 2, // ضع هنا رقم الدولة المناسبة من جدول countries
                'nationality_ar' => 'مصري',
                'nationality_en' => 'Egyptian',
                'is_active' => true,
                'nationality_id' => null,
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ]);
    }
}