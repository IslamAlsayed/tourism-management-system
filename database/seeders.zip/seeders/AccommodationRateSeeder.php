<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class AccommodationRateSeeder extends Seeder
{
    public function run(): void
    {
        DB::table('accommodation_rates')->insert([
            [
                'accommodation_id' => 1,
                // ضع هنا باقي الأعمدة المطلوبة في جدول accommodation_rates
                // مثال:
                // 'season_id' => 1,
                // 'room_type_id' => 1,
                // 'price' => 100.00,
                // 'currency_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'accommodation_id' => 2,
                // ضع هنا باقي الأعمدة المطلوبة في جدول accommodation_rates
                // 'season_id' => 2,
                // 'room_type_id' => 2,
                // 'price' => 80.00,
                // 'currency_id' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ]);
    }
}