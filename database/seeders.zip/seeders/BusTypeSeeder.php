<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class BusTypeSeeder extends Seeder
{
    public function run()
    {
        DB::table('bus_types')->insert([
            [
                'name' => 'Sedan',
                'seats' => 3,
                'company_id' => 1,
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'name' => 'Mini Van',
                'seats' => 7,
                'company_id' => 1,
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'name' => 'Coach Bus',
                'seats' => 45,
                'company_id' => 1,
                'created_at' => now(),
                'updated_at' => now()
            ]
        ]);
    }
}