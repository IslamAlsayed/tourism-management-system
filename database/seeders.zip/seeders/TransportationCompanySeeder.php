<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class TransportationCompanySeeder extends Seeder
{
    public function run()
    {
        DB::table('transportation_companies')->insert([
            [
                'name' => 'Al Jazeera Transport',
                'contact_person' => 'Mahmoud Salim',
                'phone' => '+962797777777',
                'email' => 'info@aljazeera-transport.jo',
                'created_at' => now(),
                'updated_at' => now()
            ]
        ]);
    }
}