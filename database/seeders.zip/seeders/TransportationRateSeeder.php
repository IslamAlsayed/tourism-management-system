<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class TransportationRateSeeder extends Seeder
{
    public function run()
    {
        DB::table('transportation_rates')->insert([
            [
                'bus_type_id' => 1,
                'season_name' => 'Low',
                'service_name' => 'Airport Transfer',
                'price' => 35.00,
                'base_km_included' => 40,
                'extra_km_price' => 0.8,
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'bus_type_id' => 3,
                'season_name' => 'High',
                'service_name' => 'Full Day',
                'price' => 180.00,
                'base_km_included' => 200,
                'extra_km_price' => 1.5,
                'created_at' => now(),
                'updated_at' => now()
            ]
        ]);
    }
}